function Shopinghome() {
    return ( 
        <section id="shopinghome">
            <div className="container">
                <div className="row">
                    <div className="col-md-12">
                    <h1>Welcome to Shopping Home</h1>
                    </div>
                </div>
            </div> 
        </section>
        
     );
}

export default Shopinghome;