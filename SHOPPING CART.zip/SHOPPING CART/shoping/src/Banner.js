function Banner() {
    return (
      <section id="banner">
        <div className="container">
          <div className="row">
            <div className="col-md-6">
              <h4>REACT PROJECT</h4>
              <p>React is a free and open-source front-end JavaScript library for building user interfaces based on UI components.React is a free and open-source front-end JavaScript library for building user interfaces based on UI components.</p>
              {/* <a href="/banner"><button className="btn btn-success">More details</button></a>
              */}
            </div>
            <div className="col-md-6"><img src="media/about-us.png" alt="" className="img-fluid mx-auto d-block" id="img-banner" /></div>
          </div>
        </div>
        <img src="media/border1.png" alt="" />
      </section>
    );
  
  }
  export default Banner;