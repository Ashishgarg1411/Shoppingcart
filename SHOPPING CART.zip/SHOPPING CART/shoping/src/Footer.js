import { Link } from "react-router-dom";

function Footer() {
    return ( 
        <section id="footer">
    <img src="/media/border2.png" alt="" id="footer-border"/>
    <div className="container">
      <div className="row">
        <div className="col-md-4">
          <img style={{width:'120px', height: '75px'}} src="/media/cart.png" alt="" id="footerlog"/>
          <h2>Ashish Garg</h2>
        </div>
        <div className="col-md-4">
          <h2>Address</h2>
          <p><span><i className="bi bi-house"></i></span>84/105</p>
          <p><span><i className="bi bi-phone"></i></span> +91-545454545</p>
          <p><span><i className="bi bi-telephone"></i></span> 0141-27373777</p>
        </div>
        <div className="col-md-4">
          <form action="/query" method="post">
            <input type="email" name="email" id="" placeholder="Enter Email" className="form-control"/>
            <textarea name="query" id="" placeholder="Enter Query" className="form-control mt-2 mb-2"></textarea>
            <button type="submit" className="form-control btn btn-success">Post Query</button>
          </form>
        </div>

      </div>
    </div>
    <div className="container">
      <div className="row">
        <div className="col-md-12 text-center">
        
        <Link href="https://www.whatsapp.com/"><img style={{width: "25px",height: "25px"}} src="/media/whatsapp_logo.png" alt="" class="img-fluid"/></Link>
        <Link href="https://telegram.org/"><img style={{width: "25px",height: "25px"}} src="/media/telegram_logo.png" alt="" class="img-fluid"/></Link>
        <Link href="https://www.facebook.com/"><img style={{width: "25px",height: "25px"}} src="/media/facebook_logo.png" alt="" class="img-fluid"/></Link>
        <Link href="https://www.instagram.com/"><img style={{width: "25px",height: "25px"}} src="/media/instagram_logo.png" alt="" class="img-fluid"/></Link>
        <Link href="https://twitter.com/"><img style={{width: "25px",height: "25px"}} src="/media/twitter_logo.png" alt="" class="img-fluid"/></Link>

        </div>
      </div>
    </div>
  </section>
        );
}

export default Footer;